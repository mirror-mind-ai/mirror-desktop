import type { Database, WritableDatabase } from "#db/database.ts";
import {
  decodeMetadata,
  GLOBAL_OPERATING_MODE_SESSION_ID,
  getRuntimeSession,
  upsertRuntimeSession,
} from "#mirror/runtimeSession.ts";
import { pythonJsonDumps } from "#util/pyGenerators.ts";

export const OPERATING_MODE_METADATA_KEY = "operating_mode";

// `runtime_sessions.metadata` is written by BOTH cores for as long as any
// command that touches it is still on Python -- Soul (DS7.US6) shares the very
// same row and object. Python writes it with `json.dumps(..., ensure_ascii=
// False)`, whose separators are `", "` and `": "`; `JSON.stringify` writes
// neither and escapes nothing, so the two cores stored different bytes for
// identical state until DS7.US6 corrected it. Nothing failed, because both the
// mirror-state golden and the write-parity harness compare metadata by VALUE --
// which is exactly why the divergence survived. The bytes are pinned directly
// by `operating-mode-metadata.golden.json`.

/** Port of `MODE_ICONS`: the glyph each lens is announced with. */
export const MODE_ICONS: Readonly<Record<string, string>> = {
  "Mirror Mode": "◌",
  "Builder Mode": "■",
  "Explorer Mode": "△",
  "Soul Mode": "☾",
};

/** Port of `OperatingModeState.label`: the icon, then the mode, or just the mode. */
export function modeLabel(state: OperatingModeState): string {
  const icon = MODE_ICONS[state.mode];
  return icon ? `${icon} ${state.mode}` : state.mode;
}

export interface OperatingModeState {
  mode: string;
  journey: string | null;
  /**
   * Present, and true, only on a session's stamp written under the session's
   * NAME (`--session-id` or the harness's variable), never on a guessed one
   * or the global row (CR008 option B, landed by CV9.DS8.US5). A lifecycle
   * command binds a journey from a named session's Builder stamp only when
   * this is set: `build load` with no name still stamps a guessed session,
   * so another window's load can land on this one's row.
   */
  namedSession?: true;
}

export function activateOperatingMode(
  db: WritableDatabase,
  input: { mode: string; journey?: string | null; sessionId?: string | null; named?: boolean },
  nowIso: string,
): OperatingModeState {
  const mode = input.mode.trim();
  if (!mode) throw new Error("mode must not be empty");
  const journey = input.journey?.trim() || null;
  const named = Boolean(input.sessionId) && input.named === true;
  const state: OperatingModeState = named
    ? { mode, journey, namedSession: true }
    : { mode, journey };
  // The key only when true: an unnamed stamp's bytes are what they were
  // (`operating-mode-metadata.golden.json`).
  const payload = {
    active_mode: mode,
    active_journey: journey,
    ...(named ? { named_session: true } : {}),
  };
  if (input.sessionId) {
    const session = getRuntimeSession(db, input.sessionId);
    const metadata = decodeMetadata(session?.metadata ?? null);
    metadata[OPERATING_MODE_METADATA_KEY] = payload;
    upsertRuntimeSession(
      db,
      input.sessionId,
      { metadata: pythonJsonDumps(metadata), active: true },
      nowIso,
    );
  } else {
    upsertRuntimeSession(
      db,
      GLOBAL_OPERATING_MODE_SESSION_ID,
      { metadata: pythonJsonDumps(payload), active: true },
      nowIso,
    );
  }
  return state;
}

export function deactivateOperatingMode(
  db: WritableDatabase,
  sessionId: string | null,
  nowIso: string,
): void {
  if (!sessionId) {
    upsertRuntimeSession(
      db,
      GLOBAL_OPERATING_MODE_SESSION_ID,
      { metadata: null, active: false },
      nowIso,
    );
    return;
  }
  const session = getRuntimeSession(db, sessionId);
  if (!session) return;
  const metadata = decodeMetadata(session.metadata);
  delete metadata[OPERATING_MODE_METADATA_KEY];
  upsertRuntimeSession(
    db,
    sessionId,
    { metadata: Object.keys(metadata).length > 0 ? pythonJsonDumps(metadata) : null },
    nowIso,
  );
}

/**
 * The mode stamped on ONE session row, with no fallback (CR008).
 *
 * A caller that binds on the answer must read this, not `getActiveOperatingMode`:
 * that one falls back to the global row, which whichever window loaded last
 * wrote.
 */
export function getSessionOperatingMode(
  db: Database,
  sessionId: string,
): OperatingModeState | null {
  const session = getRuntimeSession(db, sessionId);
  return stateFromPayload(decodeMetadata(session?.metadata ?? null)[OPERATING_MODE_METADATA_KEY]);
}

/** The session's own mode, else the global row: what the status line displays. */
export function getActiveOperatingMode(
  db: Database,
  sessionId: string | null,
): OperatingModeState | null {
  if (sessionId) {
    const state = getSessionOperatingMode(db, sessionId);
    if (state) return state;
  }
  const global = getRuntimeSession(db, GLOBAL_OPERATING_MODE_SESSION_ID);
  if (!global?.active) return null;
  return stateFromPayload(decodeMetadata(global.metadata));
}

function stateFromPayload(payload: unknown): OperatingModeState | null {
  if (typeof payload !== "object" || payload === null || Array.isArray(payload)) return null;
  const record = payload as Record<string, unknown>;
  const mode = typeof record.active_mode === "string" ? record.active_mode.trim() : "";
  if (!mode) return null;
  const journey =
    typeof record.active_journey === "string" && record.active_journey.trim()
      ? record.active_journey.trim()
      : null;
  return record.named_session === true ? { mode, journey, namedSession: true } : { mode, journey };
}

export function renderModeActivation(state: OperatingModeState): string {
  return state.journey
    ? `Activated ${state.mode} for ${state.journey}\n`
    : `Activated ${state.mode}\n`;
}

export function renderModeStatus(state: OperatingModeState | null): string {
  if (!state) return "Mirror Mode\n";
  return state.journey ? `${state.mode} · ${state.journey}\n` : `${state.mode}\n`;
}
